/* Ocean Notes: dependency-free encrypted MQTT transport. */
(function(root){
  'use strict';
  const te = new TextEncoder(), td = new TextDecoder();
  const cat = (...xs) => { const a = new Uint8Array(xs.reduce((n,x)=>n+x.length,0)); let p=0; for(const x of xs){a.set(x,p);p+=x.length;} return a; };
  const str = s => {const x=te.encode(s);return cat(new Uint8Array([x.length>>8,x.length&255]),x);};
  const b64 = x => {let s='';for(let i=0;i<x.length;i+=16384)s+=String.fromCharCode(...x.subarray(i,i+16384));return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');};
  const un64 = s => Uint8Array.from(atob(s.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));
  const randomID = () => b64(crypto.getRandomValues(new Uint8Array(16)));
  const createCode = () => 'SEA-'+b64(crypto.getRandomValues(new Uint8Array(32)));
  function frame(type,body=new Uint8Array()){
    const length=[];let n=body.length;do{let d=n%128;n=Math.floor(n/128);if(n)d|=128;length.push(d);}while(n);
    return cat(new Uint8Array([type,...length]),body);
  }
  class Cipher {
    static async open(code){
      if(!/^SEA-[A-Za-z0-9_-]{43}$/.test(code))throw Error('配对码格式不正确，请完整复制 SEA- 开头的配对码。');
      const raw=un64(code.slice(4));
      if(raw.length!==32)throw Error('配对码不完整。');
      const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',cat(te.encode('ocean-notes-v1/topic/'),raw)));
      const key=await crypto.subtle.importKey('raw',raw,'AES-GCM',false,['encrypt','decrypt']);
      return new Cipher(key,'ocean-notes/v1/'+b64(digest));
    }
    constructor(key,topic){this.key=key;this.topic=topic;}
    async seal(value){
      const iv=crypto.getRandomValues(new Uint8Array(12));
      const data=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:te.encode(this.topic)},this.key,te.encode(JSON.stringify(value)));
      return JSON.stringify({v:1,iv:b64(iv),data:b64(new Uint8Array(data))});
    }
    async read(text){
      if(typeof text!=='string'||text.length>524288)throw Error('packet size');
      const env=JSON.parse(text);if(env.v!==1)throw Error('version');
      const iv=un64(env.iv);if(iv.length!==12)throw Error('iv');
      const raw=await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:te.encode(this.topic)},this.key,un64(env.data));
      return JSON.parse(td.decode(raw));
    }
  }
  class Relay {
    constructor({topic,onmessage,onstate,url='wss://broker.emqx.io:8084/mqtt'}){
      Object.assign(this,{topic,onmessage,onstate,url});this.closed=false;this.packetID=1;this.attempt=0;this.ready=false;this.pending=new Map();
    }
    connect(){
      if(this.closed)return;
      this.onstate('connecting');this.ready=false;this.buffer=new Uint8Array();
      const ws=this.ws=new WebSocket(this.url,'mqtt');ws.binaryType='arraybuffer';
      this.timeout=setTimeout(()=>ws.close(),15000);
      ws.onopen=()=>{ws.send(frame(0x10,cat(str('MQTT'),new Uint8Array([4,2,0,45]),str('sea-'+randomID()))));};
      ws.onmessage=e=>{if(ws!==this.ws)return;this.lastPacket=Date.now();this.consume(new Uint8Array(e.data));};
      ws.onerror=()=>{};
      ws.onclose=()=>{
        if(ws!==this.ws)return;
        clearTimeout(this.timeout);clearInterval(this.ping);this.ready=false;
        for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(Error('连接已断开，消息未确认送达。'));}this.pending.clear();
        this.onstate(this.closed?'closed':'disconnected');
        if(!this.closed)this.retry=setTimeout(()=>this.connect(),Math.min(30000,1200*Math.pow(1.6,this.attempt++)));
      };
    }
    nextID(){this.packetID=this.packetID%65535+1;return this.packetID;}
    consume(data){
      this.buffer=cat(this.buffer,data);
      if(this.buffer.length>1048576){this.ws.close();return;}
      while(this.buffer.length>=2){
        let len=0,mul=1,p=1,d;
        do{if(p>=this.buffer.length)return;d=this.buffer[p++];len+=(d&127)*mul;mul*=128;if(p>5){this.ws.close();return;}}while(d&128);
        if(p+len>this.buffer.length)return;
        const head=this.buffer[0], body=this.buffer.slice(p,p+len);this.buffer=this.buffer.slice(p+len);
        this.packet(head,body);
      }
    }
    packet(head,b){
      const type=head>>4;
      if(type===2){
        if(b.length!==2||b[1]!==0){this.ws.close();return;}
        this.subscriptionID=this.nextID();
        this.ws.send(frame(0x82,cat(new Uint8Array([this.subscriptionID>>8,this.subscriptionID&255]),str(this.topic),new Uint8Array([1]))));
      }else if(type===9){
        if(b.length<3||b[0]*256+b[1]!==this.subscriptionID||b[2]===128){this.ws.close();return;}
        clearTimeout(this.timeout);this.ready=true;this.attempt=0;this.lastPacket=Date.now();this.onstate('connected');
        this.ping=setInterval(()=>{if(Date.now()-this.lastPacket>70000){this.ws.close();return;}if(this.ws.readyState===1)this.ws.send(frame(0xc0));},20000);
      }else if(type===3){
        if(b.length<2)return;const size=b[0]*256+b[1];if(size+2>b.length)return;
        const topic=td.decode(b.slice(2,size+2));let start=size+2;const qos=(head>>1)&3;
        if(qos===1){if(start+2>b.length)return;const id=b.slice(start,start+2);this.ws.send(frame(0x40,id));start+=2;}
        if(qos>1||topic!==this.topic)return;
        this.onmessage(td.decode(b.slice(start)));
      }else if(type===4&&b.length===2){
        const id=b[0]*256+b[1],p=this.pending.get(id);if(p){clearTimeout(p.timer);p.resolve();this.pending.delete(id);}
      }
    }
    publish(text){
      if(!this.ready||this.ws.readyState!==1)return Promise.reject(Error('还未连接，消息没有发送。'));
      const id=this.nextID();return new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{this.pending.delete(id);reject(Error('中转未确认，请检查网络。'));},12000);
        this.pending.set(id,{resolve,reject,timer});
        this.ws.send(frame(0x32,cat(str(this.topic),new Uint8Array([id>>8,id&255]),te.encode(text))));
      });
    }
    close(){this.closed=true;clearTimeout(this.retry);clearTimeout(this.timeout);clearInterval(this.ping);if(this.ws){if(this.ws.readyState===1)this.ws.send(frame(0xe0));this.ws.close();}}
  }
  root.OceanCore={Cipher,Relay,createCode,randomID,frame};
})(globalThis);
