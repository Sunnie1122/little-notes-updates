/* Device-local appearance: never sent in presence packets. */
(function(root){'use strict';
const ranges={avatarScale:[.5,1.6,1],messageScale:[.8,1.4,1],deliveryScale:[.6,1.4,1],backgroundOpacity:[0,.75,.35]};
function image(value,max=450000){return typeof value==='string'&&value.length<=max&&/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(value)?value:'';}
function normalize(value){const a=value&&typeof value==='object'?value:{},out={};for(const [key,[min,max,def]]of Object.entries(ranges)){const n=Number(a[key]);out[key]=a[key]!==undefined&&Number.isFinite(n)?Math.min(max,Math.max(min,n)):def;}out.avatar=image(a.avatar);out.background=image(a.background);out.stickers=Array.isArray(a.stickers)?a.stickers.filter(x=>image(x,30000)&&x.startsWith('data:image/png;')).slice(0,8):[];return out;}
root.NoteAppearance={normalize,ranges,image};
})(typeof window==='undefined'?globalThis:window);
