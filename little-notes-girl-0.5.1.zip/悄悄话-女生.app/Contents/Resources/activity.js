(function(root){
 'use strict';
 class ActivityTracker{
  constructor(){this.reset();}
  reset(){this.signature='';this.since=0;this.lastSent='';this.lastAt=-Infinity;}
  observe(value,prefs,online,now){
   if(!prefs.autoStatus||!value||value.idle){this.signature='';this.lastSent='';return null;}
   const app=String(value.name||''),bundle=String(value.bundle||''),signature=bundle||app;if(!signature)return null;
   if(this.signature!==signature){this.signature=signature;this.since=now;this.lastSent='';return null;}
   if(!online||now-this.since<20000||this.lastSent===signature||now-this.lastAt<180000)return null;
   let text='';
   if(bundle==='com.openai.chat'||bundle==='com.openai.codex'||/chatgpt/i.test(app))text=prefs.templates.gpt;
   else if(bundle==='com.tencent.xinWeChat'||/^(WeChat|微信)$/i.test(app))text=prefs.templates.wechat;
   else if(prefs.studyApps.split(/[,，、\n]/).map(x=>x.trim().toLowerCase()).filter(Boolean).includes(app.toLowerCase()))text=prefs.templates.study;
   if(!text)return null;this.lastSent=signature;this.lastAt=now;return text;
  }
  failed(){this.lastSent='';}
 }
 root.OceanActivity={ActivityTracker};
})(globalThis);
