'use strict';
const post=(action,extra={})=>window.webkit?.messageHandlers?.ocean.postMessage(JSON.stringify({action,...extra}));
window.flyMessage=item=>{
 if(item.style==='envelope')return;
 const box=document.getElementById('courier');box.className=item.style||'envelope';document.getElementById('courier-art').src='envelope.png';document.getElementById('sender').textContent='';document.getElementById('text').textContent='有一条悄悄话';const img=document.getElementById('drawing');img.hidden=true;img.removeAttribute('src');requestAnimationFrame(()=>requestAnimationFrame(()=>box.classList.add('running')));
};
document.getElementById('courier').addEventListener('animationend',e=>{if(e.target.id==='courier')post('flightDone');});post('flightReady');
