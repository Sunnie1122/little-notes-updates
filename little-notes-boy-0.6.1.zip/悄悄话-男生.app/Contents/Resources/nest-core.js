/* Shared, bounded dollhouse state and clock-driven character routines. No network or DOM. */
(function(root){
 'use strict';
 const defs=[
 ['bed','碎花木床','休息',230,'sleep'],['sofa','蔷薇双人沙发','休息',210,'sit'],['chair','花园扶手椅','休息',135,'read'],['tea','蕾丝小茶桌','生活',150,'tea'],
 ['tv','复古小电视','娱乐',130,'watch'],['desk','奶油写字台','生活',185,'read'],['wardrobe','花枝衣柜','装饰',160,'dress'],['shelf','小书架','生活',150,'read'],
 ['lamp','褶边落地灯','装饰',95,'rest'],['plant','花叶小盆栽','装饰',90,'water'],['rug','蔷薇地毯','装饰',245,'dance'],['window','格纹窗帘','装饰',175,'look'],
 ['computer','胡桃游戏桌','娱乐',215,'game'],['console','双人游戏机柜','娱乐',195,'game'],['bath','泡泡浴缸','生活',230,'bath'],['vanity','小小梳妆台','生活',170,'dress'],
 ['record','唱片机','娱乐',130,'dance'],['fridge','鼠尾草冰箱','生活',110,'snack'],['kitchen','奶油小厨房','生活',165,'cook'],['dining','两人餐桌','生活',195,'eat'],
 ['cat','猫爬架','娱乐',115,'play'],['bike','森林健身车','娱乐',130,'exercise'],['fish','金鱼小水族箱','装饰',145,'fish'],['coat','日常衣帽架','装饰',100,'dress']
 ];
 const catalog=defs.map((d,i)=>({id:d[0],kind:d[0],name:d[1],group:d[2],width:d[3],activity:d[4],sheet:i<12?'rose':'life',cell:i%12}));
 const walnutNames=['胡桃格纹木床','苔绿双人沙发','皮革阅读椅','胡桃小茶桌','胡桃电视柜','胡桃书桌','黄铜把手衣柜','胡桃藏书架','暖光落地灯','雾蓝蕨叶盆栽','鼠尾草编织毯','鼠尾草窗帘'];
 defs.slice(0,12).forEach((d,i)=>catalog.push({id:d[0]+'-walnut',kind:d[0],name:walnutNames[i],group:d[2],width:d[3],activity:d[4],sheet:'walnut',cell:i}));
 const lookup=Object.fromEntries(catalog.map(x=>[x.id,x]));
 const clamp=(n,a,b,f)=>Number.isFinite(Number(n))?Math.max(a,Math.min(b,Number(n))):f;
 const cleanID=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{1,64}$/.test(x)?x:'';
 const lines=[{girl:'今天也想和你待在一起。',boy:'那就一起在小窝里慢慢过。'},{girl:'再陪我玩一局好不好？',boy:'好呀，这一局我们一队。'},{girl:'有点困了，想窝一会儿。',boy:'我在旁边陪着你。'},{girl:'想喝点热乎乎的。',boy:'给你留了最喜欢的小杯子。'},{girl:'这里越来越像我们的家了。',boy:'因为每一样都有我们的小心思。'}];
 const line=x=>typeof x==='string'?x.trim().slice(0,80):'';
 function item(v){if(!v||!lookup[v.asset]||!cleanID(v.id))return null;const scale=clamp(v.scale,.65,1.4,1),a=lookup[v.asset],half=a.width*scale/2;return {id:v.id,asset:v.asset,x:clamp(v.x,half+15,985-half,500),y:clamp(v.y,a.kind==='window'?145:250,a.kind==='window'?300:605,420),scale,flip:v.flip===true};}
 function initial(){return {v:1,revision:{at:0,by:''},autonomous:true,theme:'cream',items:[
 {id:'home-window',asset:'window',x:480,y:218},{id:'home-bed',asset:'bed',x:190,y:375},{id:'home-computer',asset:'computer',x:805,y:325},
 {id:'home-sofa',asset:'sofa',x:570,y:420},{id:'home-tv',asset:'tv',x:590,y:265},{id:'home-bath',asset:'bath',x:205,y:570},
 {id:'home-rug',asset:'rug',x:600,y:555},{id:'home-plant',asset:'plant',x:905,y:505}
 ].map(item),commands:{},chatter:true,lines:lines.map(x=>({...x})),dialogue:null};}
 function normalize(v,now=Date.now()){
  if(!v||v.v!==1||!Array.isArray(v.items))return initial();const ids=new Set(),items=[];
  for(const raw of v.items.slice(0,24)){const x=item(raw);if(x&&!ids.has(x.id)){ids.add(x.id);items.push(x);}}
  const revision={at:clamp(v.revision?.at,0,now+300000,0),by:cleanID(v.revision?.by)};
  const commands={};for(const role of ['girl','boy']){const c=v.commands?.[role];if(c&&ids.has(c.itemId)&&Number.isFinite(c.start)&&Number.isFinite(c.until)&&c.start<=now+5000&&c.until>now&&c.until<=c.start+90000)commands[role]={itemId:c.itemId,start:c.start,until:c.until};}
  const custom=Array.isArray(v.lines)?v.lines.slice(0,8).map(x=>({girl:line(x?.girl),boy:line(x?.boy)})).filter(x=>x.girl||x.boy):lines.map(x=>({...x}));let dialogue=null;const d=v.dialogue;if(d&&Number.isFinite(d.start)&&d.start<=now+5000&&d.start+45000>now&&(line(d.girl)||line(d.boy)))dialogue={girl:line(d.girl),boy:line(d.boy),start:d.start};
  return {v:1,revision,items,commands,autonomous:v.autonomous!==false,theme:['cream','sage','rose'].includes(v.theme)?v.theme:'cream',chatter:v.chatter!==false,lines:custom,dialogue};
 }
 function newer(a,b){return a.revision.at>b.revision.at||(a.revision.at===b.revision.at&&a.revision.by>b.revision.by);}
 function merge(local,remote,now=Date.now()){const a=normalize(local,now);if(!remote||remote.v!==1)return a;const b=normalize(remote,now);return newer(b,a)?b:a;}
 function edit(value,op,by,now=Date.now()){
  const s=normalize(value,now);if(!op||typeof op!=='object')return s;let changed=false;
  if(op.kind==='add'&&lookup[op.asset]&&cleanID(op.id)&&s.items.length<24&&!s.items.some(i=>i.id===op.id)){s.items.push(item({id:op.id,asset:op.asset,x:op.x,y:op.y,scale:1}));changed=true;}
  if(op.kind==='move'||op.kind==='scale'||op.kind==='flip'){const i=s.items.findIndex(x=>x.id===op.id);if(i>=0){const x=s.items[i];s.items[i]=item({...x,...(op.kind==='move'?{x:op.x,y:op.y}:op.kind==='scale'?{scale:op.scale}:{flip:!x.flip})});changed=true;}}
  if(op.kind==='remove'&&s.items.some(x=>x.id===op.id)){s.items=s.items.filter(x=>x.id!==op.id);for(const role of ['girl','boy'])if(s.commands[role]?.itemId===op.id)delete s.commands[role];changed=true;}
  if(op.kind==='style'&&lookup[op.asset]){const i=s.items.findIndex(x=>x.id===op.id);if(i>=0&&lookup[s.items[i].asset].kind===lookup[op.asset].kind){s.items[i]=item({...s.items[i],asset:op.asset});changed=true;}}
  if(op.kind==='auto'){s.autonomous=op.enabled===true;s.commands={};s.dialogue=null;changed=true;}
  if(op.kind==='chatter'){s.chatter=op.enabled===true;changed=true;}
  if(op.kind==='dialogue'&&(line(op.girl)||line(op.boy))){s.dialogue={girl:line(op.girl),boy:line(op.boy),start:now};s.commands={};changed=true;}
  if(op.kind==='addLine'&&s.lines.length<8&&(line(op.girl)||line(op.boy))){s.lines.push({girl:line(op.girl),boy:line(op.boy)});changed=true;}
  if(op.kind==='removeLine'&&Number.isInteger(op.index)&&op.index>=0&&op.index<s.lines.length){s.lines.splice(op.index,1);changed=true;}
  if(op.kind==='theme'&&['cream','sage','rose'].includes(op.theme)){s.theme=op.theme;changed=true;}
  if(op.kind==='interact'&&s.items.some(x=>x.id===op.id)){s.dialogue=null;for(const r of op.role==='both'?['girl','boy']:[op.role])if(['girl','boy'].includes(r))s.commands[r]={itemId:op.id,start:now,until:now+45000};changed=true;}
  if(op.kind==='free'){s.commands={};s.dialogue=null;s.autonomous=true;changed=true;}
  if(changed)s.revision={at:Math.max(now,s.revision.at+1),by:cleanID(by)};return s;
 }
 function hash(text){let x=2166136261;for(let i=0;i<text.length;i++)x=Math.imul(x^text.charCodeAt(i),16777619);return x>>>0;}
 const words={sleep:'窝在床上打个盹',sit:'在沙发上发一会儿呆',read:'翻翻喜欢的书',tea:'慢慢喝一口热茶',watch:'陪你看一集电视',dress:'整理一下今天的自己',rest:'在暖光里歇一会儿',water:'给小花一点水',dance:'跟着旋律晃一晃',look:'看看窗外的风景',game:'来一局小游戏',bath:'泡进暖暖的泡泡里',snack:'找一点好吃的',cook:'做一份热乎乎的饭',eat:'一起好好吃饭',play:'逗一逗小毛球',exercise:'慢慢踩两圈',fish:'看小金鱼游来游去',wander:'在小窝里溜达',idle:'安安静静陪着你'};
 function conversation(s,now){if(s.dialogue&&s.dialogue.start+45000>now)return {...s.dialogue,key:'talk-'+s.dialogue.start};if(!s.autonomous||!s.chatter||!s.lines.length||Object.values(s.commands).some(c=>c.until>now))return null;const slot=Math.floor(now/95000),start=slot*95000;if(now-start>38000)return null;return {...s.lines[hash('talk'+slot)%s.lines.length],start,key:'chat-'+slot};}
 function target(s,role,now){
  const c=s.commands[role]?.until>now?s.commands[role]:null,slot=Math.floor(now/38000),offset=role==='girl'?-35:35;
  const talk=conversation(s,now);if(talk&&!c){const rug=s.items.find(x=>lookup[x.asset].kind==='rug'),x=(rug?rug.x:500)+offset,y=rug?rug.y-20:530;return {x,y,action:'chat',text:'和你说说小话',key:talk.key,depth:y+3};}
  let f=c?s.items.find(x=>x.id===c.itemId):null, key=c?'command-'+c.start+'-'+c.itemId:'auto-'+slot;
  if(!f&&!s.autonomous)return {x:role==='girl'?435:515,y:550,action:'idle',text:words.idle,key:'idle',depth:551};
  if(!f){const options=s.items.filter(i=>!['wardrobe','coat','window','lamp'].includes(lookup[i.asset].kind));const h=hash(slot+'-'+(slot%4===0?'together':role));f=options.length&&h%7!==0?options[h%options.length]:null;}
  if(!f){const h=hash(role+slot);return {x:350+h%300,y:450+h%125,action:'wander',text:words.wander,key,depth:575};}
  const def=lookup[f.asset],action=def.activity;let x=f.x+offset,y=f.y+28,depth=y;
  if(action==='watch'||(action==='game'&&def.kind==='console')){const sofa=s.items.find(i=>lookup[i.asset].kind==='sofa');if(sofa){x=sofa.x+offset;y=sofa.y-18;depth=sofa.y+2;}else y=f.y+70;}
  if(['sleep','bath'].includes(action)){y=f.y-def.width*.27*f.scale;depth=f.y+2;}
  if(action==='sit'){y=f.y-18;depth=f.y+2;}
  return {x:clamp(x,60,940,500),y:clamp(y,200,605,500),action,text:words[action],key:key+'-'+f.id,itemId:f.id,depth};
 }
 function path(s,from,to){
  const step=25,cols=39,rows=17,start=[Math.round((from.x-25)/step),Math.round((from.y-200)/step)],end=[Math.round((to.x-25)/step),Math.round((to.y-200)/step)];
  const key=(x,y)=>x+','+y,queue=[start],visited=new Map([[key(...start),null]]);let found=false;
  const blocked=(x,y)=>s.items.some(f=>{const a=lookup[f.asset];if(['rug','window','lamp','plant'].includes(a.kind)||f.id===to.itemId)return false;return Math.abs(x-f.x)<a.width*f.scale*.30&&Math.abs(y-(f.y-12))<22;});
  for(let n=0;n<queue.length&&n<2000;n++){const p=queue[n];if(p[0]===end[0]&&p[1]===end[1]){found=true;break;}for(const d of [[1,0],[-1,0],[0,1],[0,-1]]){const x=p[0]+d[0],y=p[1]+d[1],k=key(x,y);if(x<0||x>=cols||y<0||y>=rows||visited.has(k)||blocked(25+x*step,200+y*step))continue;visited.set(k,p);queue.push([x,y]);}}
  if(!found)return [{x:to.x,y:to.y}];const points=[];let p=end;while(p){points.unshift({x:25+p[0]*step,y:200+p[1]*step});p=visited.get(key(...p));}points.push({x:to.x,y:to.y});return points.slice(1);
 }
 root.NestCore={catalog,lookup,initial,normalize,merge,edit,newer,target,path,conversation,words};
 if(typeof module!=='undefined')module.exports=root.NestCore;
})(typeof globalThis!=='undefined'?globalThis:this);
