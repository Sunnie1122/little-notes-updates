'use strict';
const $=id=>document.getElementById(id),{Cipher,Relay,createCode,randomID}=OceanCore;
const defaults={deviceID:randomID(),nickname:'',role:'girl',code:'',popups:true,sound:false,shareUsage:false,autoStatus:false,deliveryStyle:'envelope',templates:{gpt:'我在和 GPT 对话呢',wechat:'我在用微信呀',study:'学习 ing'},studyApps:'OneNote, Anki, Obsidian, Goodnotes',history:[],nest:NestCore.initial(),appearance:{avatarScale:1,messageScale:1,deliveryScale:1,backgroundOpacity:.35,avatar:'',background:'',stickers:[]}};
let state={...defaults},cipher=null,relay=null,peer=null,connected=false,epoch=0,booted=false,lastPresence=0;
let pending=new Map(),seen=new Set(),localUsage={day:'',currentApp:'',idle:true,totals:[]};
let activity=new OceanActivity.ActivityTracker();
const native=!!window.webkit?.messageHandlers?.ocean;
function bridge(action,data={}){if(native)window.webkit.messageHandlers.ocean.postMessage(JSON.stringify({action,...data}));}
function ask(text){return new Promise(resolve=>{const d=$('confirmation');$('confirmation-text').textContent=text;const done=x=>{d.close();resolve(x);};$('confirmation-cancel').onclick=()=>done(false);$('confirmation-yes').onclick=()=>done(true);d.oncancel=e=>{e.preventDefault();done(false);};d.showModal();});}
function name(){return $('nickname').value.trim()||(state.role==='girl'?'她':'他');}
function save(){state.nickname=name();state.history=state.history.slice(0,50);if(native)bridge('save',{state});else localStorage.setItem('little-note-preview',JSON.stringify(state));}
function textEl(tag,text,cls){const e=document.createElement(tag);e.textContent=text;if(cls)e.className=cls;return e;}
function feedback(text,error=false){$('feedback').textContent=text;$('feedback').classList.toggle('error',error);bridge('widgetFeedback',{text,error});}
function isLive(){return connected&&peer&&Date.now()-peer.received<22000;}
function syncWidget(){syncNest();bridge('widgetState',{state:{role:state.role,nickname:name(),paired:!!state.code,connected,peer:isLive()?{name:peer.name,role:peer.role,sharing:peer.sharing,currentApp:peer.currentApp,idle:peer.idle}:null,autoStatus:state.autoStatus,shareUsage:state.shareUsage,style:state.deliveryStyle,appearance:state.appearance}});}
function renderPeer(){
  const live=isLive();$('peer-label').textContent=live?peer.name+' · 在线':'等待对方上线';$('usage-list').replaceChildren();
  $('peer-app').textContent=live&&peer.sharing?'对方正在使用：'+(peer.currentApp||'暂不可用')+(peer.idle?'（暂时空闲）':''):live?'对方未开启额外的软件状态共享':'';
  if(live&&peer.sharing&&Array.isArray(peer.totals))for(const x of peer.totals.slice(0,7)){const row=document.createElement('div');row.className='usage-row';row.append(textEl('span',String(x.name||'应用')),textEl('span',Math.floor((Number(x.seconds)||0)/60)+' 分钟'));$('usage-list').append(row);}
  syncWidget();
}
function renderHistory(){
  const box=$('history');box.replaceChildren();if(!state.history.length){box.append(textEl('p','还没有来信。','hint'));return;}
  for(const item of state.history){const card=document.createElement('div');card.className='history-item';const meta=document.createElement('div');meta.className='history-meta';meta.append(textEl('span',(item.out?'你 → 对方':item.name+' → 你')+' · '+new Date(item.at).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})),textEl('span',item.status||''));if(!item.out&&!item.opened){card.append(meta,textEl('p','有一条还没点开的来信。','history-text'));const b=textEl('button','点击查看');b.onclick=()=>bridge('popup',{item:{...item,openEnvelope:true}});card.append(b);box.append(card);continue;}card.append(meta,textEl('p',item.text||'给你的一张小画','history-text'));if(validImage(item.image)){const img=document.createElement('img');img.src=item.image;img.alt='手绘的小画';card.append(img);}if(!item.out&&item.kind!=='reply'){for(const reaction of ['收到啦','想你了','抱抱']){const b=textEl('button',reaction);b.onclick=()=>sendNote({text:reaction,kind:'reply',replyTo:item.id});card.append(b);}}box.append(card);}
}
function addHistory(item){state.history.unshift(item);state.history=state.history.slice(0,50);renderHistory();save();}
function delivery(id,status){const h=state.history.find(x=>x.id===id);if(h){h.status=status;renderHistory();save();}bridge('widgetDelivery',{id,status});}
function validImage(value){return typeof value==='string'&&value.length<=30000&&/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(value);}
async function transmit(body){
  if(!cipher||!connected)throw Error('网络还未连接，消息没有发送。');const context=cipher;
  const msg={...body,v:1,from:state.deviceID,role:state.role,name:name(),at:Date.now(),id:body.id||randomID()};
  const encrypted=await context.seal(msg);if(context!==cipher||!relay)throw Error('配对已改变，消息未发送。');await relay.publish(encrypted);return msg;
}
async function presence(){if(!connected)return;lastPresence=Date.now();const value={kind:'presence',sharing:!!state.shareUsage,nest:state.nest,nestVersion:1};if(state.shareUsage)Object.assign(value,localUsage);try{await transmit(value);}catch(e){}}
function connection(s){connected=s==='connected';$('connection').textContent=connected?'中转已连接':s==='connecting'?'正在连接…':s==='closed'?'尚未配对':'连接断开，正在重连';$('connection').className=connected?'online':'';if(connected)presence();renderPeer();}
async function connect(code){
  const candidate=await Cipher.open(code),generation=++epoch;if(relay)relay.close();relay=null;cipher=candidate;peer=null;seen.clear();
  for(const [id,p] of pending){clearTimeout(p.timer);delivery(id,'连接改变，未确认');}pending.clear();state.code=code;$('paircode').value=code;save();
  relay=new Relay({topic:candidate.topic,onstate:s=>{if(generation===epoch)connection(s);},onmessage:raw=>{if(generation===epoch)receive(raw,candidate,generation);}});relay.connect();syncWidget();
}
async function receive(raw,context,generation){
  let msg;try{msg=await context.read(raw);}catch(e){return;}
  if(generation!==epoch||!msg||msg.v!==1||msg.from===state.deviceID||typeof msg.from!=='string'||typeof msg.id!=='string'||typeof msg.at!=='number'||Math.abs(Date.now()-msg.at)>120000)return;
  if(seen.has(msg.id))return;seen.add(msg.id);if(seen.size>2048)seen.delete(seen.values().next().value);
  if(peer&&peer.id!==msg.from&&Date.now()-peer.received<22000){feedback('有第三台设备使用同一个配对码，请创建新配对码。',true);return;}
  const newPeer=!peer||peer.id!==msg.from;peer={...(peer||{}),id:msg.from,name:String(msg.name||'对方').slice(0,20),role:msg.role==='boy'?'boy':msg.role==='girl'?'girl':state.role==='girl'?'boy':'girl',received:Date.now()};
  if(msg.kind==='presence'){peer.nestVersion=msg.nestVersion===1;if(peer.nestVersion)acceptNest(msg.nest);peer.sharing=msg.sharing===true;peer.at=msg.at;if(peer.sharing){peer.currentApp=String(msg.currentApp||'').slice(0,120);peer.idle=!!msg.idle;peer.totals=Array.isArray(msg.totals)?msg.totals.slice(0,30):[];}else{delete peer.currentApp;delete peer.totals;}if(newPeer)presence();renderPeer();return;}
  if(msg.kind==='nest'){peer.nestVersion=true;acceptNest(msg.nest);renderPeer();return;}
  renderPeer();
  if(msg.kind==='ack'&&typeof msg.replyTo==='string'){const p=pending.get(msg.replyTo),h=state.history.find(x=>x.id===msg.replyTo&&x.out);if(p){clearTimeout(p.timer);pending.delete(msg.replyTo);}if(h){const status=msg.clickToOpen?(msg.displayed?'对方已点开查看':'已送到，等待对方点开'):msg.envelope?(msg.displayed?'对方已拆开信封':'信封已送到，等待拆开'):msg.displayed?'已在对方屏幕显示':'对方已收到，动画关闭';if(!['对方已点开查看','对方已拆开信封'].includes(h.status))delivery(msg.replyTo,status);}return;}
  if(!['message','reply','drawing'].includes(msg.kind)||typeof msg.text!=='string'||msg.text.length>240)return;
  if(msg.kind==='drawing'&&!validImage(msg.image))return;
  const item={id:msg.id,kind:msg.kind,text:msg.text,role:peer.role,style:['envelope','animal','bubble'].includes(msg.style)?msg.style:'envelope',name:peer.name,at:msg.at,out:false,opened:false,status:msg.auto?'自动状态':'已收到',image:msg.kind==='drawing'?msg.image:undefined,auto:!!msg.auto};addHistory(item);
  if(state.popups&&native)bridge('popup',{item,sound:state.sound});else transmit({kind:'ack',replyTo:msg.id,displayed:false}).catch(()=>{});
}
async function sendNote(note,{auto=false}={}){
  const kind=note.kind==='drawing'?'drawing':note.kind==='reply'?'reply':'message',text=String(note.text||'').trim().slice(0,240);
  if(kind==='drawing'&&!validImage(note.image)){feedback('这张小画太大，请简化一些再发。',true);return false;}
  if(!text&&kind!=='drawing'){feedback('写一句话，或在画板上画一点什么。',true);return false;}
  if(!isLive()){if(!auto)feedback('对方暂未上线。请让对方联网并保持小程序运行。',true);return false;}
  const id=randomID(),item={id,kind,text:text||(kind==='drawing'?'给你画了一张小画':''),role:state.role,style:note.style||state.deliveryStyle,name:name(),at:Date.now(),out:true,status:'正在发送…',auto};if(kind==='drawing')item.image=note.image;if(note.replyTo)item.replyTo=note.replyTo;
  addHistory(item);const timer=setTimeout(()=>{pending.delete(id);delivery(id,'未确认送达，请重试');},18000);pending.set(id,{timer});
  try{await transmit(item);if(pending.has(id))delivery(id,'已发出，等待对方确认');bridge('widgetSent',{id,text:item.text});return true;}catch(e){clearTimeout(timer);pending.delete(id);delivery(id,'发送失败');if(!auto)feedback(e.message,true);return false;}
}

function syncNest(){bridge('nestFrame',{state:{nest:state.nest,role:state.role,nickname:name(),paired:!!state.code,connected,peer:isLive()?{name:peer.name,role:peer.role}:null,peerNest:!!(isLive()&&peer.nestVersion)}});}
function acceptNest(value){const next=NestCore.merge(state.nest,value);if(NestCore.newer(next,state.nest)){state.nest=next;save();syncNest();}}
window.nativeNestRefresh=()=>syncNest();
window.nativeNestEdit=op=>{const next=NestCore.edit(state.nest,op,state.deviceID);if(!NestCore.newer(next,state.nest)){syncNest();return;}state.nest=next;save();syncNest();if(connected)transmit({kind:'nest',nest:state.nest}).catch(()=>bridge('nestError',{text:'已保存在本机，连接恢复后同步小窝。'}));};
window.nativeComposeSend=note=>sendNote(note);
window.nativePopupDisplayed=id=>{const h=state.history.find(x=>x.id===id&&!x.out);if(h){h.opened=true;h.status='已查看';renderHistory();save();}transmit({kind:'ack',replyTo:id,displayed:true,clickToOpen:true,envelope:h?.style==='envelope'}).catch(()=>{});};
window.nativeEnvelopeArrived=id=>{transmit({kind:'ack',replyTo:id,displayed:false,clickToOpen:true}).catch(()=>{});};
window.nativeRestoreEnvelopes=()=>{if(booted)bridge('restoreEnvelopes',{items:state.history.filter(x=>!x.out&&!x.opened).slice().reverse()});};
window.nativePopupReply=(id,text)=>sendNote({kind:'reply',replyTo:id,text});
window.nativeUsage=value=>{localUsage=value;if(connected&&state.shareUsage&&Date.now()-lastPresence>2000)presence();};
window.nativeSharingChanged=enabled=>{state.shareUsage=!!enabled;$('shareUsage').checked=state.shareUsage;$('sharing-banner').hidden=!enabled;if(!enabled)localUsage={day:'',currentApp:'',idle:true,totals:[]};save();presence();syncWidget();};
window.nativeAutoChanged=enabled=>{state.autoStatus=!!enabled;$('autoStatus').checked=state.autoStatus;$('auto-banner').hidden=!enabled;activity.reset();save();syncWidget();};
window.nativeActivity=async value=>{
  const text=activity.observe(value,state,isLive(),Date.now());if(!text)return;const ok=await sendNote({text},{auto:true});if(!ok)activity.failed();
};
window.nativeError=message=>feedback(message,true);
window.nativeStyleChanged=style=>{if(['envelope','animal','bubble'].includes(style)){state.deliveryStyle=style;save();syncWidget();}};
window.nativeBootstrap=value=>{
  if(booted)return;booted=true;state={...defaults,...value,templates:{...defaults.templates,...value.templates},history:Array.isArray(value.history)?value.history.map(x=>!x.out&&x.style!=='envelope'&&x.opened===undefined?{...x,opened:true}:x):[]};if(state.nickname==='小鲸鱼')state.nickname='';
  $('nickname').value=state.nickname;$('paircode').value=state.code||'';document.querySelectorAll('[data-role]').forEach(b=>{b.classList.toggle('selected',b.dataset.role===state.role);if(value.roleLocked&&b.dataset.role!==state.role)b.hidden=true;});
  for(const key of ['popups','sound','shareUsage','autoStatus'])$(key).checked=!!state[key];$('sharing-banner').hidden=!state.shareUsage;$('auto-banner').hidden=!state.autoStatus;
  state.nest=NestCore.normalize(state.nest);state.appearance=NoteAppearance.normalize(state.appearance);renderAppearance();$('gpt-template').value=state.templates.gpt;$('wx-template').value=state.templates.wechat;$('study-template').value=state.templates.study;$('study-apps').value=state.studyApps;renderHistory();save();syncWidget();if(state.code)connect(state.code).catch(e=>feedback(e.message,true));
};
$('create').onclick=async()=>{if(state.code&&!await ask('创建新码会断开原来的配对，另一台 Mac 也要输入新码。继续吗？'))return;try{await connect(createCode());feedback('配对码已创建，请复制后私下发给对方。');}catch(e){feedback(e.message,true);}};
$('join').onclick=()=>connect($('paircode').value.trim()).catch(e=>feedback(e.message,true));
$('copy').onclick=async()=>{const code=$('paircode').value.trim();if(!code){feedback('请先创建配对码。',true);return;}if(native){bridge('copy',{text:code});feedback('已复制，配对码请只给彼此。');}else{try{await navigator.clipboard.writeText(code);}catch(e){$('paircode').type='text';$('paircode').select();}}};
$('reveal').onclick=()=>{const show=$('paircode').type==='password';$('paircode').type=show?'text':'password';$('reveal').textContent=show?'隐藏':'显示';};
$('leave').onclick=async()=>{if(!await ask('解除配对，同时关闭本机自动状态和软件共享？'))return;++epoch;if(relay)relay.close();relay=null;cipher=null;connected=false;peer=null;state.code='';$('paircode').value='';for(const[id,p]of pending){clearTimeout(p.timer);delivery(id,'已解除配对');}pending.clear();bridge('sharing',{enabled:false});bridge('autoStatus',{enabled:false});nativeSharingChanged(false);nativeAutoChanged(false);connection('closed');save();};
$('nickname').onchange=()=>{save();presence();syncWidget();};
document.querySelectorAll('[data-role]').forEach(b=>b.onclick=()=>{state.role=b.dataset.role;document.querySelectorAll('[data-role]').forEach(x=>x.classList.toggle('selected',x===b));save();presence();syncWidget();});
for(const key of ['popups','sound'])$(key).onchange=()=>{state[key]=$(key).checked;save();};
for(const [id,key]of [['shareUsage','sharing'],['autoStatus','autoStatus']])$(id).onchange=()=>{const enabled=$(id).checked;if(enabled&&!state.code){$(id).checked=false;feedback('先完成配对，再在本机开启这个功能。',true);return;}if(native)bridge(key,{enabled});else{$(id).checked=false;feedback('请在 Mac 小程序中设置。',true);}};
for(const [id,key]of [['gpt-template','gpt'],['wx-template','wechat'],['study-template','study']])$(id).onchange=()=>{state.templates[key]=$(id).value.trim().slice(0,80);save();};
$('study-apps').onchange=()=>{state.studyApps=$('study-apps').value.slice(0,240);save();};
$('open-nest').onclick=()=>bridge('openNest');
$('open-desktop').onclick=()=>bridge('showWidget');$('position').onclick=()=>bridge('toggleCorner');
$('test').onclick=()=>bridge('popup',{item:{id:'demo-'+randomID(),kind:'message',role:state.role==='girl'?'boy':'girl',name:'对方',text:'想跟你说：今天也有一点想你。',style:state.deliveryStyle,demo:true,at:Date.now()},sound:state.sound});
$('clear-history').onclick=async()=>{if(await ask('清空这台 Mac 的消息记录？')){state.history=[];renderHistory();save();}};
setInterval(()=>{renderPeer();if(connected&&Date.now()-lastPresence>7500)presence();},3000);
window.addEventListener('beforeunload',()=>{if(relay)relay.close();});
if(native)bridge('ready');else{let loaded={};try{loaded=JSON.parse(localStorage.getItem('little-note-preview')||'{}');}catch(e){}nativeBootstrap(loaded);}

function renderAppearance(){
 const a=state.appearance;for(const key of Object.keys(NoteAppearance.ranges)){const input=$('appearance-'+key);if(input){input.value=a[key];$('value-'+key).textContent=Math.round(a[key]*100)+'%';}}
 for(const key of ['avatar','background']){const img=$(key+'-preview');img.hidden=!a[key];if(a[key])img.src=a[key];else img.removeAttribute('src');}
 const box=$('sticker-library');box.replaceChildren();a.stickers.forEach((image,index)=>{const wrap=document.createElement('div'),img=document.createElement('img'),b=textEl('button','移除');img.src=image;img.alt='小贴纸 '+(index+1);b.onclick=()=>{state.appearance.stickers.splice(index,1);appearanceChanged();};wrap.append(img,b);box.append(wrap);});
}
function appearanceChanged(){state.appearance=NoteAppearance.normalize(state.appearance);renderAppearance();save();syncWidget();}
for(const [key,label]of Object.entries({avatarScale:'桌面小人大小',messageScale:'消息框与文字大小',deliveryScale:'来信图标与动画大小',backgroundOpacity:'背景图片浓度'})){
 const wrap=document.createElement('label'),input=document.createElement('input'),output=document.createElement('output');wrap.textContent=label+' ';input.type='range';input.id='appearance-'+key;input.min=NoteAppearance.ranges[key][0];input.max=NoteAppearance.ranges[key][1];input.step='.05';input.setAttribute('aria-label',label);output.id='value-'+key;wrap.append(output,input);$('size-controls').append(wrap);input.oninput=()=>{state.appearance[key]=Number(input.value);appearanceChanged();};
}
document.querySelectorAll('[data-import]').forEach(b=>b.onclick=()=>{if(b.dataset.import==='sticker'&&state.appearance.stickers.length>=8){$('appearance-feedback').textContent='小贴纸已满 8 张，先移除一张再添加。';return;}bridge('importImage',{target:b.dataset.import});});
document.querySelectorAll('[data-reset]').forEach(b=>b.onclick=()=>{state.appearance[b.dataset.reset]='';appearanceChanged();});
$('reset-sizes').onclick=()=>{for(const key of ['avatarScale','messageScale','deliveryScale'])state.appearance[key]=1;appearanceChanged();};
window.nativeImageError=text=>{$('appearance-feedback').textContent=text;};
window.nativeImportedImage=async value=>{
 if(!['avatar','background','sticker'].includes(value.target))return;
 try{const img=new Image();await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=reject;img.src=value.image;});if(!img.width||!img.height)throw Error();
 const canvas=document.createElement('canvas'),limit=value.target==='background'?640:value.target==='avatar'?300:192;let ratio=Math.min(1,limit/Math.max(img.width,img.height)),encoded='';
 do{canvas.width=Math.max(1,Math.round(img.width*ratio));canvas.height=Math.max(1,Math.round(img.height*ratio));canvas.getContext('2d').drawImage(img,0,0,canvas.width,canvas.height);encoded=canvas.toDataURL(value.target==='background'?'image/jpeg':'image/png',.8);ratio*=.8;}while(encoded.length>(value.target==='sticker'?30000:450000)&&canvas.width>24&&canvas.height>24);
 if(!NoteAppearance.image(encoded,value.target==='sticker'?30000:450000))throw Error();if(value.target==='sticker'){if(state.appearance.stickers.length>=8)throw Error();state.appearance.stickers.push(encoded);}else state.appearance[value.target]=encoded;appearanceChanged();$('appearance-feedback').textContent='已保存，桌面会立即换上。';
 }catch(e){$('appearance-feedback').textContent='这张图片无法导入，请换一张 PNG 或 JPEG 图片。';}
};
renderAppearance();

window.nativeUpdaterState=value=>{$('update-version').textContent='当前版本 '+value.version+(value.available?'':' · 更新组件未能启动');$('automatic-updates').checked=value.enabled;$('automatic-updates').disabled=!value.available;};
$('check-updates').onclick=()=>bridge('checkUpdates');$('automatic-updates').onchange=()=>bridge('automaticUpdates',{enabled:$('automatic-updates').checked});
