'use strict';
const $=id=>document.getElementById(id),post=(action,extra={})=>window.webkit?.messageHandlers?.ocean.postMessage(JSON.stringify({action,...extra}));
let local={role:'girl',nickname:'我',style:'envelope'},item=null,lastItem=null,mode='text',replyTo='',busy=false,lastSentID='',ink='#876049';
const unopened=[];let selectedSticker='';
function renderLetters(){
 $('unread-inbox').hidden=!unopened.length;
 for(const [style,button,badge,label] of [['envelope','sealed-letter','letter-count','信封'],['animal','unread-animal','animal-count','豆狸'],['bubble','unread-bubble','bubble-count','泡泡']]){
  const count=unopened.filter(x=>(x.style||'envelope')===style).length;$(button).hidden=!count;$(badge).textContent=count>99?'99+':String(count);$(button).setAttribute('aria-label','查看'+label+'来信，'+count+' 条未读');
 }size();
}
window.queueEnvelope=value=>{if(!unopened.some(x=>x.id===value.id))unopened.push(value);renderLetters();post('envelopeArrived',{id:value.id,demo:!!value.demo});};
window.restoreEnvelopes=values=>{for(const value of values)if(!unopened.some(x=>x.id===value.id))unopened.push(value);renderLetters();};
const canvas=$('canvas'),ctx=canvas.getContext('2d');let drawing=false,drawn=false,undo=[];
function size(){const a=NoteAppearance.normalize(local.appearance);const visible=['editor','note','notification','unread-inbox'].filter(id=>!$(id).hidden);const height=visible.reduce((n,id)=>n+$(id).getBoundingClientRect().height+5,0)+134*a.avatarScale+43;post('widgetResize',{height:Math.ceil(height)});}
function applyAppearance(){
 const a=NoteAppearance.normalize(local.appearance),root=document.documentElement.style;
 root.setProperty('--avatar-scale',a.avatarScale);root.setProperty('--message-scale',a.messageScale);root.setProperty('--delivery-scale',a.deliveryScale);root.setProperty('--note-background',a.background?'url("'+a.background+'")':'none');root.setProperty('--background-opacity',a.backgroundOpacity);
 document.querySelectorAll('.person .avatar').forEach(el=>{el.style.backgroundImage=a.avatar?'url("'+a.avatar+'")':'';el.classList.toggle('custom-avatar',!!a.avatar);});
 const box=$('custom-stickers');box.replaceChildren();for(const image of a.stickers){const b=document.createElement('button'),img=document.createElement('img');img.src=image;img.alt='自己的小贴纸';b.setAttribute('aria-label','选择自己的小贴纸');b.classList.toggle('chosen',image===selectedSticker);b.append(img);b.onclick=()=>{selectedSticker=image;applyAppearance();$('sticker-selection').textContent='已选好，点「送过去」发送。';};box.append(b);}size();
}

function notify(text){$('notification').textContent=text;$('notification').hidden=!text;size();}
function focus(){post('focusWidget');}
function setMode(value){mode=value;$('message').hidden=mode!=='text';$('drawing').hidden=mode!=='draw';$('stickers').hidden=mode!=='sticker';for(const key of ['text','draw','sticker'])$(key+'-tab').classList.toggle('active',mode===key);size();}
function openEditor(reply=''){
  replyTo=reply;document.body.classList.add('interacting');post('beginCompose');$('note').hidden=true;$('notification').hidden=true;$('editor').hidden=false;$('editor-title').textContent=reply?'回一句给你':'给你写一句';$('editor-hint').textContent='⌘ + Enter 发送';setMode('text');focus();$('message').focus();
}
function reset(){document.body.classList.remove('interacting');item=null;$('note').hidden=true;$('editor').hidden=true;$('notification').hidden=true;busy=false;$('send').disabled=false;size();}
window.desktopState=value=>{
 local=value;applyAppearance();const names={girl:local.role==='girl'?local.nickname+' · 我':local.peer?.name||'她',boy:local.role==='boy'?local.nickname+' · 我':local.peer?.name||'他'};$('girl-name').textContent=names.girl;$('boy-name').textContent=names.boy;document.querySelectorAll('[data-person]').forEach(b=>{b.hidden=b.dataset.person!==(local.role||'girl');});
 $('online').textContent='';const dot=document.createElement('i');$('online').append(dot,document.createTextNode(local.peer?'对方在线':local.paired?'等你上线':'先配对一下'));$('online').className=local.peer?'live':'';
 $('online').title=local.peer?.sharing?'对方正在使用：'+local.peer.currentApp:local.connected?'中转已连接':'连接中';$('local-status').textContent=local.shareUsage?'软件共享中':local.autoStatus?'自动状态中':'';
 document.querySelectorAll('[data-style]').forEach(b=>b.classList.toggle('active',b.dataset.style===local.style));
};
window.showCoupleMessage=value=>{
 const unreadIndex=unopened.findIndex(x=>x.id===value.id);if(unreadIndex>=0)unopened.splice(unreadIndex,1);renderLetters();document.body.classList.add('interacting');item=value;lastItem=value;$('editor').hidden=true;$('notification').hidden=true;$('note').hidden=false;$('sender-avatar').className='avatar '+(item.role==='girl'?'girl':'boy');$('from').textContent=(item.demo?'本机预览 · ':'来自 ')+item.name+(item.auto?' · 自动状态':'');$('note-text').textContent=item.text||'';$('note-image').hidden=!item.image;if(item.image)$('note-image').src=item.image;else $('note-image').removeAttribute('src');$('note-status').textContent='';size();post('displayed',{id:item.id,demo:!!item.demo});
};
for(const [style,button] of [['envelope','sealed-letter'],['animal','unread-animal'],['bubble','unread-bubble']])$(button).onclick=()=>{if(!$('editor').hidden){$('editor-hint').textContent='先发送或收起正在写的内容，再查看来信。';return;}const next=unopened.find(x=>(x.style||'envelope')===style);if(next)post('openEnvelope',{item:next});};
window.resetWidget=reset;
window.desktopFeedback=value=>{busy=false;$('send').disabled=false;if(value.error){$('editor-hint').textContent=value.text;notify(value.text);}};
window.desktopSent=value=>{busy=false;$('send').disabled=false;lastSentID=value.id;$('message').value='';if(mode==='draw'){ctx.clearRect(0,0,canvas.width,canvas.height);drawn=false;undo=[];}if(!$('note').hidden)return;$('editor').hidden=true;document.body.classList.remove('interacting');notify('已送出，等对方的小人收到。');setTimeout(()=>{if($('editor').hidden&&$('note').hidden)notify('');},4500);};
window.desktopDelivery=value=>{if(value.id===lastSentID)notify(value.status);};
document.querySelectorAll('[data-person]').forEach(b=>b.onclick=()=>{if(!local.paired){post('settings');return;}if(b.dataset.person!==local.role&&lastItem){showCoupleMessage(lastItem);return;}openEditor();});
$('text-tab').onclick=()=>setMode('text');$('draw-tab').onclick=()=>{setMode('draw');focus();};$('sticker-tab').onclick=()=>setMode('sticker');
$('close-editor').onclick=()=>{reset();post('closePopup');};$('close-note').onclick=()=>{reset();post('closePopup');};$('reply').onclick=()=>{const id=item?.demo?'':item?.id||'';openEditor(id);};
document.querySelectorAll('#reactions button:not(#reply)').forEach(b=>b.onclick=()=>{if(item?.demo){reset();post('closePopup');return;}post('widgetSend',{note:{kind:'reply',replyTo:item?.id||'',text:b.textContent,style:local.style}});post('closePopup');});
document.querySelectorAll('[data-style]').forEach(b=>b.onclick=()=>{local.style=b.dataset.style;post('style',{style:local.style});document.querySelectorAll('[data-style]').forEach(x=>x.classList.toggle('active',x===b));});
async function send(){if(busy)return;let note={kind:replyTo?'reply':'message',replyTo,text:$('message').value.trim(),style:local.style};
 if(mode==='draw'){if(!drawn){$('editor-hint').textContent='先画一点什么，再送过去。';return;}let image=canvas.toDataURL('image/png');if(image.length>30000){const small=document.createElement('canvas');small.width=260;small.height=120;small.getContext('2d').drawImage(canvas,0,0,260,120);image=small.toDataURL('image/png');}if(image.length>30000){$('editor-hint').textContent='小画太大，请简化一些。';return;}note={kind:'drawing',text:'给你画了一张小画',image,style:local.style};}
 if(mode==='sticker'&&selectedSticker){note={kind:'drawing',text:'送你一张小贴纸',image:selectedSticker,style:local.style};}
 else if(mode==='sticker'){note.text=local.style==='animal'?'豆狸带来一句：想你啦':local.style==='bubble'?'把想念装进泡泡里':'一封给你的悄悄话';}
 if(!note.text&&note.kind!=='drawing'){$('editor-hint').textContent='写一句想说的话吧。';return;}busy=true;$('send').disabled=true;$('editor-hint').textContent='正在送过去…';post('widgetSend',{note});setTimeout(()=>{if(busy){busy=false;$('send').disabled=false;$('editor-hint').textContent='还没确认，检查网络后再试。';}},16000);
}
$('send').onclick=send;$('message').onkeydown=e=>{if((e.metaKey||e.ctrlKey)&&e.key==='Enter'){e.preventDefault();send();}};
document.querySelectorAll('[data-sticker]').forEach(b=>b.onclick=()=>{selectedSticker='';local.style=b.dataset.sticker;post('style',{style:local.style});document.querySelectorAll('[data-style]').forEach(x=>x.classList.toggle('active',x.dataset.style===local.style));send();});
function point(e){const r=canvas.getBoundingClientRect();return [(e.clientX-r.left)*canvas.width/r.width,(e.clientY-r.top)*canvas.height/r.height];}
canvas.onpointerdown=e=>{undo.push(ctx.getImageData(0,0,canvas.width,canvas.height));if(undo.length>12)undo.shift();canvas.setPointerCapture(e.pointerId);drawing=true;drawn=true;const [x,y]=point(e);ctx.beginPath();ctx.moveTo(x,y);ctx.strokeStyle=ink;ctx.lineWidth=5;ctx.lineCap='round';ctx.lineJoin='round';ctx.lineTo(x+.1,y+.1);ctx.stroke();};
canvas.onpointermove=e=>{if(!drawing)return;const [x,y]=point(e);ctx.lineTo(x,y);ctx.stroke();};canvas.onpointerup=canvas.onpointercancel=()=>{drawing=false;};
document.querySelectorAll('[data-color]').forEach(b=>b.onclick=()=>{ink=b.dataset.color;document.querySelectorAll('[data-color]').forEach(x=>x.classList.toggle('selected',x===b));});
$('undo').onclick=()=>{if(undo.length){ctx.putImageData(undo.pop(),0,0);drawn=undo.length>0;}};$('clear').onclick=()=>{ctx.clearRect(0,0,canvas.width,canvas.height);drawn=false;undo=[];};
$('open-nest').onclick=()=>post('openNest');
$('settings').onclick=()=>post('settings');$('corner').onclick=()=>post('toggleCorner');$('preview').onclick=()=>post('demo');
document.addEventListener('keydown',e=>{if(e.key==='Escape'){reset();post('closePopup');}});
post('popupReady');
