'use strict';
const $=id=>document.getElementById(id),C=NestCore,native=!!window.webkit?.messageHandlers?.ocean;
const post=(action,data={})=>{if(native)window.webkit.messageHandlers.ocean.postMessage(JSON.stringify({action,...data}));};
let state=C.initial(),frame={},arranging=false,category='全部',selected='',chosen='bed',detailKind='',drag=null,queuedFrame=null,lastItems='',lastFrame=0,worldScale=1;
const names={girl:'咩',boy:'yc'},actors={girl:{x:435,y:550,key:'',path:[],target:null},boy:{x:520,y:550,key:'',path:[],target:null}};
const kindNames={bed:'床',sofa:'双人沙发',chair:'扶手椅',tea:'小茶桌',tv:'电视',desk:'书桌',wardrobe:'衣柜',shelf:'书架',lamp:'落地灯',plant:'盆栽',rug:'地毯',window:'窗帘',computer:'电脑游戏桌',console:'游戏机柜',bath:'浴缸',vanity:'梳妆台',record:'唱片机',fridge:'冰箱',kitchen:'小厨房',dining:'双人餐桌',cat:'猫爬架',bike:'健身车',fish:'鱼缸',coat:'衣帽架'};
function say(text){$('nest-feedback').textContent=text;}
function art(el,a){el.style.backgroundImage='url(furniture-'+a.sheet+'.png)';el.style.backgroundPosition=(a.cell%4)*100/3+'% '+Math.floor(a.cell/4)*50+'%';}
function button(text,fn){const b=document.createElement('button');b.type='button';b.textContent=text;b.onclick=fn;return b;}
function commit(op){state=C.edit(state,op,'preview',Date.now());render();if(native)post('nestEdit',{op});else localStorage.setItem('little-nest-preview',JSON.stringify(state));}
function catalog(){const box=$('catalog');box.replaceChildren();for(const a of C.catalog.filter(x=>!x.id.endsWith('-walnut')&&(category==='全部'||x.group===category))){const b=button('',()=>{selected='';detailKind=a.kind;chosen=a.id;renderDetail();catalog();});b.className='catalog-card'+(a.kind===detailKind?' selected':'');b.setAttribute('aria-label','选择'+kindNames[a.kind]);const pic=document.createElement('span');pic.className='thumb';art(pic,a);const text=document.createElement('span');text.className='label';text.textContent=kindNames[a.kind];b.append(pic,text);const count=C.catalog.filter(x=>x.kind===a.kind).length;if(count>1){const tag=document.createElement('small');tag.textContent=count+'款';b.append(tag);}box.append(b);}}
function renderDetail(){
 const current=state.items.find(x=>x.id===selected);if(selected&&!current)selected='';if(current){chosen=current.asset;detailKind=C.lookup[chosen].kind;}
 $('item-detail').hidden=!detailKind;if(!detailKind)return;$('detail-title').textContent=kindNames[detailKind]+(current?' · 已摆放':'');const choices=$('style-choices');choices.replaceChildren();
 for(const a of C.catalog.filter(x=>x.kind===detailKind)){const b=button('',()=>{chosen=a.id;if(current)commit({kind:'style',id:current.id,asset:chosen});else renderDetail();});b.className=a.id===chosen?'selected':'';b.setAttribute('aria-label','选择风格：'+a.name);const thumb=document.createElement('span');thumb.className='thumb';art(thumb,a);const label=document.createElement('span');label.textContent=a.name;b.append(thumb,label);choices.append(b);}
 $('add-item').hidden=!!current;$('add-item').disabled=state.items.length>=24;$('placed-controls').hidden=!current;if(current){$('item-scale').value=current.scale;$('scale-output').textContent=Math.round(current.scale*100)+'%';}
}
function furniture(){
 const serial=JSON.stringify(state.items)+selected;if(serial===lastItems)return;lastItems=serial;const layer=$('furniture-layer');layer.replaceChildren();
 for(const f of state.items){const a=C.lookup[f.asset],b=button('',()=>{if(b.dataset.dragged==='yes'){b.dataset.dragged='';return;}selected=f.id;chosen=f.asset;detailKind=a.kind;renderDetail();furniture();if(!arranging)interact(f.id);});b.className='furniture'+(f.id===selected?' selected':'');b.dataset.id=f.id;b.dataset.kind=a.kind;b.setAttribute('aria-label',a.name+(arranging?'，拖动摆放':'，点击互动'));b.title=a.name;b.style.left=f.x+'px';b.style.top=f.y+'px';b.style.width=a.width*f.scale+'px';b.style.height=a.width*f.scale*341/384+'px';b.style.zIndex=a.kind==='rug'?1:a.kind==='window'?2:Math.round(f.y);const pic=document.createElement('span');pic.className='art';art(pic,a);if(f.flip)pic.style.transform='scaleX(-1)';const label=document.createElement('span');label.className='title';label.textContent=a.name;b.append(pic,label);
  b.onpointerdown=e=>{if(e.button!==0)return;selected=f.id;chosen=f.asset;detailKind=a.kind;renderDetail();b.classList.add('selected');b.setPointerCapture(e.pointerId);drag={id:f.id,startX:e.clientX,startY:e.clientY,x:f.x,y:f.y,node:b,moved:false};};
  b.onpointermove=e=>{if(!drag||drag.id!==f.id)return;const dx=(e.clientX-drag.startX)/worldScale,dy=(e.clientY-drag.startY)/worldScale;if(Math.abs(dx)+Math.abs(dy)>5)drag.moved=true;const preview=C.edit(state,{kind:'move',id:f.id,x:drag.x+dx,y:drag.y+dy},'preview');const next=preview.items.find(x=>x.id===f.id);b.style.left=next.x+'px';b.style.top=next.y+'px';drag.next=next;};
  b.onpointerup=()=>{if(!drag||drag.id!==f.id)return;const d=drag;drag=null;if(queuedFrame){const q=queuedFrame;queuedFrame=null;window.nestState(q);}if(d.moved&&d.next){b.dataset.dragged='yes';commit({kind:'move',id:f.id,x:d.next.x,y:d.next.y});say('摆好啦，已经记住这个位置。');}else{lastItems='';furniture();}};
  b.onpointercancel=()=>{drag=null;lastItems='';if(queuedFrame){const q=queuedFrame;queuedFrame=null;window.nestState(q);}else furniture();};layer.append(b);
 }
}
function interact(id){commit({kind:'interact',id,role:$('who').value});say('给他们安排一点小日常，过一会儿会继续自己玩。');}
function render(){
 $('world').className=state.theme+(arranging?' arranging':'');$('autonomy').checked=state.autonomous;$('placed-count').textContent=state.items.length+'/24 件';document.querySelectorAll('[data-theme]').forEach(b=>b.classList.toggle('selected',b.dataset.theme===state.theme));furniture();renderDetail();renderChat();for(const a of Object.values(actors))a.key='';
}
function mode(edit){arranging=edit;$('live-mode').setAttribute('aria-pressed',String(!edit));$('edit-mode').setAttribute('aria-pressed',String(edit));$('room-hint').textContent=edit?'直接拖动家具摆位置。选中后可换风格、调大小；方向键也能移动。':'拖动家具摆位置；轻点家具，让他们过去互动。';$('world').classList.toggle('arranging',edit);}
window.nestState=value=>{
 if(drag){queuedFrame=value;return;}frame=value||{};const before=JSON.stringify(state);state=C.normalize(frame.nest);names.girl=frame.role==='girl'?(frame.nickname||'咩'):(frame.peer?.name||'咩');names.boy=frame.role==='boy'?(frame.nickname||'yc'):(frame.peer?.name||'yc');
 $('home-names').textContent=names.girl+' 和 '+names.boy+' 的小日子';document.querySelector('.wall-label').textContent=names.girl+' & '+names.boy;for(const role of ['girl','boy']){$('name-'+role).textContent=names[role];$('daily-'+role).textContent=names[role];}const who=$('who');who.options[0].textContent=names.girl+'和'+names.boy+'一起';who.options[1].textContent=names.girl;who.options[2].textContent=names.boy;
 $('sync-state').textContent=frame.peerNest?'小窝已连上 · 共同布置':frame.peer?'对方更新后可一起布置':frame.paired?'本机已保存 · 等对方上线同步':'本机小窝 · 配对后可一起布置';if(before!==JSON.stringify(state))render();
};
window.nestError=text=>say(String(text||'暂时没有保存成功，请再试一次。'));
function animate(time){
 const dt=Math.min(100,time-lastFrame||16);lastFrame=time;const now=Date.now(),active=new Set();
 for(const role of ['girl','boy']){const a=actors[role],t=C.target(state,role,now),el=$('resident-'+role);if(a.key!==t.key||!a.target||Math.abs(a.target.x-t.x)>1||Math.abs(a.target.y-t.y)>1){a.key=t.key;a.target=t;a.path=C.path(state,a,t);a.talkUntil=now+6500;}
  let moving=false;if(a.path.length){const p=a.path[0],dx=p.x-a.x,dy=p.y-a.y,d=Math.hypot(dx,dy),step=dt*.12;if(d<=step){a.x=p.x;a.y=p.y;a.path.shift();}else{a.x+=dx/d*step;a.y+=dy/d*step;}moving=a.path.length>0;}
  el.style.left=a.x+'px';el.style.top=a.y+'px';el.style.zIndex=Math.round(moving?a.y+5:t.depth+3);el.dataset.action=t.action;el.classList.toggle('walking',moving);el.classList.toggle('talking',now<a.talkUntil&&!moving);$('bubble-'+role).textContent=t.text;$('activity-'+role).textContent=moving?'正慢慢走过去':t.text;if(!moving&&t.itemId)active.add(t.itemId);
 }
 const talk=C.conversation(state,now);if(talk){for(const role of ['girl','boy']){const elapsed=now-talk.start,visible=role==='girl'?elapsed>=5000&&elapsed<22000:elapsed>=16000&&elapsed<38000;const el=$('resident-'+role);if(visible&&!el.classList.contains('walking')&&talk[role]){$('bubble-'+role).textContent=talk[role];el.classList.add('talking');}}}
 document.querySelectorAll('.furniture').forEach(b=>b.classList.toggle('in-use',active.has(b.dataset.id)));requestAnimationFrame(animate);
}
function resize(){worldScale=$('room-viewport').clientWidth/1000;$('world').style.transform='scale('+worldScale+')';$('room-viewport').style.height=(650*worldScale)+'px';}
new ResizeObserver(resize).observe($('room-viewport'));
$('live-mode').onclick=()=>mode(false);$('edit-mode').onclick=()=>mode(true);$('autonomy').onchange=()=>commit({kind:'auto',enabled:$('autonomy').checked});$('free-time').onclick=()=>{commit({kind:'free'});say('让他们慢慢安排自己的小日子。');};$('back-desktop').onclick=()=>{if(native)post('closeNest');else say('这是本机预览，小窝已经保存。');};
$('add-item').onclick=()=>{if(state.items.length>=24){say('小窝最多摆 24 件家具，先收回一件再添新东西。');return;}const id='f-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);selected=id;mode(true);commit({kind:'add',id,asset:chosen,x:450+(state.items.length%3)*65,y:C.lookup[chosen].kind==='window'?200:490});say('已放进小窝，拖动它找个喜欢的位置。');};
$('detail-close').onclick=()=>{detailKind='';selected='';renderDetail();catalog();furniture();};$('item-scale').oninput=()=>{if(selected)commit({kind:'scale',id:selected,scale:Number($('item-scale').value)});};$('flip-item').onclick=()=>{if(selected)commit({kind:'flip',id:selected});};$('remove-item').onclick=()=>{const id=selected;selected='';commit({kind:'remove',id});say('已收回家具，随时能再从家具栏放进来。');};$('use-item').onclick=()=>{if(selected){mode(false);interact(selected);}};
document.querySelectorAll('[data-category]').forEach(b=>b.onclick=()=>{category=b.dataset.category;document.querySelectorAll('[data-category]').forEach(x=>x.classList.toggle('selected',x===b));catalog();});document.querySelectorAll('[data-theme]').forEach(b=>b.onclick=()=>commit({kind:'theme',theme:b.dataset.theme}));
document.addEventListener('keydown',e=>{if(!arranging||!selected||/INPUT|SELECT|TEXTAREA/.test(e.target.tagName))return;const d={ArrowLeft:[-10,0],ArrowRight:[10,0],ArrowUp:[0,-10],ArrowDown:[0,10]}[e.key];if(d){e.preventDefault();const f=state.items.find(x=>x.id===selected);if(f)commit({kind:'move',id:f.id,x:f.x+d[0],y:f.y+d[1]});}});
let lastLines='';
function renderChat(){$('chatter').checked=state.chatter;const serial=JSON.stringify(state.lines);if(serial===lastLines)return;lastLines=serial;const list=$('chat-lines');list.replaceChildren();state.lines.forEach((pair,index)=>{const row=document.createElement('div');row.className='chat-line';const text=document.createElement('span');text.className='line-text';text.textContent=names.girl+'：'+pair.girl+'\n'+names.boy+'：'+pair.boy;row.append(text,button('用这段',()=>{$('say-girl').value=pair.girl;$('say-boy').value=pair.boy;}),button('移除',()=>commit({kind:'removeLine',index})));list.append(row);});}
$('chatter').onchange=()=>commit({kind:'chatter',enabled:$('chatter').checked});
function spoken(kind){const girl=$('say-girl').value.trim(),boy=$('say-boy').value.trim();if(!girl&&!boy){say('先写一句小人想说的话。');return;}if(kind==='addLine'&&state.lines.length>=8){say('台词本最多 8 段，先移除一段再添加。');return;}commit({kind,girl,boy});say(kind==='dialogue'?'他们会走到一起，轮流说出这段小话。':'已经加入台词本，他们自己聊天时也会用到。');}
$('play-dialogue').onclick=()=>spoken('dialogue');$('save-dialogue').onclick=()=>spoken('addLine');
if(native)post('nestReady');else{try{state=C.normalize(JSON.parse(localStorage.getItem('little-nest-preview')||'null'));}catch(e){}window.nestState({nest:state,role:'girl',nickname:'咩'});}catalog();render();resize();requestAnimationFrame(animate);
